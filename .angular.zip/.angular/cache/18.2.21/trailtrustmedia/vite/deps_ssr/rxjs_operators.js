import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  require_operators
} from "./chunk-PY7D3I5M.js";
import "./chunk-NQ4HTGF6.js";
export default require_operators();
//# sourceMappingURL=rxjs_operators.js.map
