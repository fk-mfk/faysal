import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent {
  currentYear = new Date().getFullYear();

  quickLinks = [
    { label: 'About Us', path: '/about' },
    { label: 'Services', path: '/services' },
    { label: 'Portfolio', path: '/portfolio' },
    { label: 'Blog', path: '/blog' }
  ];

  services = [
    { label: 'Publicity Campaigns', path: '/services' },
    { label: 'Review Management', path: '/services' },
    { label: 'Digital Marketing', path: '/services' },
    { label: 'Travel Business Consulting', path: '/services' }
  ];

  socialLinks = [
    { name: 'LinkedIn', icon: '💼', url: 'https://linkedin.com/company/trailtrustmedia' },
    { name: 'Twitter', icon: '🐦', url: 'https://twitter.com/trailtrustmedia' },
    { name: 'Instagram', icon: '📷', url: 'https://instagram.com/trailtrustmedia' },
    { name: 'Facebook', icon: '👥', url: 'https://facebook.com/trailtrustmedia' }
  ];
}



