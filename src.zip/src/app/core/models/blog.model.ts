export interface BlogPost {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  content: string;
  author: Author;
  category: string;
  tags: string[];
  image: string;
  publishedDate: string;
  readTime: number;
}

export interface Author {
  name: string;
  avatar: string;
  bio: string;
}



