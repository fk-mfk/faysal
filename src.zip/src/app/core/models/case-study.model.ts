export interface CaseStudy {
  id: string;
  title: string;
  client: string;
  industry: string;
  image: string;
  challenge: string;
  solution: string;
  results: CaseStudyResult[];
  testimonial?: string;
}

export interface CaseStudyResult {
  metric: string;
  value: string;
  description: string;
}



