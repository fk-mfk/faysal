export interface TeamMember {
  id: string;
  name: string;
  position: string;
  avatar: string;
  bio: string;
  expertise: string[];
  social: {
    linkedin?: string;
    twitter?: string;
  };
}



