import { Injectable, signal } from '@angular/core';
import { Service } from '../models/service.model';
import { Testimonial } from '../models/testimonial.model';
import { CaseStudy } from '../models/case-study.model';
import { BlogPost } from '../models/blog.model';
import { TeamMember } from '../models/team.model';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  private services = signal<Service[]>([
    {
      id: '1',
      title: 'Review Management',
      description: 'Build trust with travelers through proactive reputation monitoring, strategic review responses, and authentic review generation across all major platforms.',
      icon: '⭐',
      features: [
        'Multi-platform review monitoring (RedBus, Paytm/AbhiBus, Google, TripAdvisor, Yelp)',
        'Professional response strategies',
        'Review generation campaigns',
        'Sentiment analysis and reporting',
        'Crisis management for negative reviews',
        '24/7 reputation monitoring',
        'Competitive benchmarking'
      ],
      bestSeller: true,
      process: [
        { step: 1, title: 'Audit', description: 'Comprehensive review of your current reputation' },
        { step: 2, title: 'Setup', description: 'Configuring monitoring across all platforms' },
        { step: 3, title: 'Management', description: 'Responding to reviews and engaging customers' },
        { step: 4, title: 'Growth', description: 'Implementing review generation strategies' }
      ]
    },
    {
      id: '2',
      title: 'Travel Business Consulting',
      description: 'Position your travel business for success with expert guidance on brand strategy, business compliance, legal matters, and crisis communication.',
      icon: '💼',
      features: [
        'GST compliance and tax advisory',
        'Legal compliance and governance consulting',
        'Regulatory issues resolution and support',
        'Brand positioning and differentiation',
        'Messaging strategy development',
        'Competitive analysis',
        'Crisis communication planning',
        'Brand guidelines and standards'
      ],
      process: [
        { step: 1, title: 'Assessment', description: 'Deep dive into your brand and market position' },
        { step: 2, title: 'Development', description: 'Creating comprehensive brand strategy' },
        { step: 3, title: 'Implementation', description: 'Rolling out new positioning and messaging' },
        { step: 4, title: 'Refinement', description: 'Continuous improvement and adaptation' }
      ]
    },
    {
      id: '3',
      title: 'Digital Marketing',
      description: 'Engage travelers where they are with targeted social media management, content creation, and influencer partnerships tailored for the travel industry.',
      icon: '📱',
      features: [
        'Social media strategy and management',
        'Travel content creation and curation',
        'Influencer marketing campaigns',
        'WhatsApp marketing and automation',
        'SMS marketing campaigns',
        'Email marketing and automation',
        'Paid advertising (Facebook, Instagram, Google)',
        'Performance tracking and analytics'
      ],
      process: [
        { step: 1, title: 'Planning', description: 'Content strategy and calendar development' },
        { step: 2, title: 'Creation', description: 'Producing engaging travel content' },
        { step: 3, title: 'Distribution', description: 'Publishing and promoting across channels' },
        { step: 4, title: 'Analysis', description: 'Tracking performance and optimizing' }
      ]
    },
    {
      id: '4',
      title: 'Publicity Campaigns',
      description: 'Amplify your travel brand through strategic media outreach, press releases, and compelling storytelling that resonates with travelers and drives brand awareness.',
      icon: '📢',
      features: [
        'Strategic media outreach to travel publications',
        'Press release writing and distribution',
        'Brand storytelling and positioning',
        'Travel influencer partnerships',
        'Event publicity and launch campaigns',
        'Media relations management',
        'Brand visibility optimization'
      ],
      process: [
        { step: 1, title: 'Discovery', description: 'Understanding your brand, goals, and target audience' },
        { step: 2, title: 'Strategy', description: 'Creating a customized publicity roadmap' },
        { step: 3, title: 'Execution', description: 'Launching campaigns and securing media coverage' },
        { step: 4, title: 'Optimization', description: 'Analyzing results and refining approach' }
      ]
    }
  ]);

  private testimonials = signal<Testimonial[]>([
    {
      id: '1',
      name: 'Sarah Johnson',
      company: 'Coastal Express Tours',
      position: 'Owner',
      avatar: '👩‍💼',
      rating: 5,
      text: 'TrailTrustMedia completely transformed our online presence. We went from 3.2 to 4.8 stars on Google, our bookings increased by 65% in just 4 months, and we\'re now ranking #1 for key travel routes in our region!'
    },
    {
      id: '2',
      name: 'Michael Chen',
      company: 'Mountain View Bus Service',
      position: 'Marketing Director',
      avatar: '👨‍💼',
      rating: 5,
      text: 'The publicity campaign exceeded all expectations. We were featured in 5 major travel publications, got invited to industry events, and saw a 180% increase in brand searches. Their strategic approach and industry connections are unmatched!'
    },
    {
      id: '3',
      name: 'Emily Rodriguez',
      company: 'Sunset Travel Adventures',
      position: 'CEO',
      avatar: '👩‍💼',
      rating: 5,
      text: 'Professional, strategic, and results-driven. They helped us navigate a challenging reputation crisis and turned it into our biggest opportunity to showcase our customer commitment. Our trust score increased by 45% and negative reviews dropped by 78%!'
    },
    {
      id: '4',
      name: 'David Thompson',
      company: 'Heritage Coach Lines',
      position: 'Operations Manager',
      avatar: '👨‍💼',
      rating: 5,
      text: 'The review management and GST compliance consulting services are game-changers. Our response rate is now 100%, customers love our engagement, and we\'re fully compliant with all regulations. Peace of mind and great reviews!'
    },
    {
      id: '5',
      name: 'Lisa Wang',
      company: 'Adventure Trails Bus Co.',
      position: 'Founder',
      avatar: '👩‍💼',
      rating: 5,
      text: 'Their WhatsApp and social media campaigns delivered incredible results! We gained 2,000+ followers, generated 500+ qualified leads through WhatsApp marketing, and saw a 210% ROI in the first quarter. The content quality is outstanding!'
    },
    {
      id: '6',
      name: 'Rajesh Kumar',
      company: 'Express Travel Services',
      position: 'Managing Director',
      avatar: '👨‍💼',
      rating: 5,
      text: 'Managing reviews across RedBus, Paytm, and AbhiBus was overwhelming until TrailTrustMedia stepped in. They monitor all platforms 24/7, respond professionally, and our ratings improved across all channels. Bookings are up 85%!'
    },
    {
      id: '7',
      name: 'Priya Sharma',
      company: 'Himalayan Journey Bus Tours',
      position: 'Marketing Head',
      avatar: '👩‍💼',
      rating: 5,
      text: 'The SMS and email marketing campaigns they designed are incredibly effective. We\'re reaching customers at the right time with personalized offers, and our repeat booking rate jumped from 15% to 42%. Simply phenomenal results!'
    },
    {
      id: '8',
      name: 'Amit Patel',
      company: 'City Connect Transport',
      position: 'Owner',
      avatar: '👨‍💼',
      rating: 5,
      text: 'Their legal and GST compliance support saved us from major headaches. They streamlined our documentation, ensured full regulatory compliance, and even helped resolve pending issues. Now we focus on business while they handle the compliance!'
    }
  ]);

  private caseStudies = signal<CaseStudy[]>([
    {
      id: '1',
      title: 'Transforming Regional Bus Service into Travel Destination Brand',
      client: 'Coastal Express Tours',
      industry: 'Travel & Tourism',
      image: '🚌',
      challenge: 'Coastal Express was perceived as just another bus service with low online visibility and a 3.2-star rating.',
      solution: 'Implemented comprehensive reputation management, launched "Coastal Stories" content series, and secured partnerships with travel bloggers.',
      results: [
        { metric: 'Star Rating', value: '4.8⭐', description: 'Improved from 3.2 in 4 months' },
        { metric: 'Bookings', value: '+65%', description: 'Year-over-year increase' },
        { metric: 'Media Mentions', value: '12', description: 'Features in travel publications' }
      ],
      testimonial: 'TrailTrustMedia didn\'t just manage our reputation - they transformed how travelers see us.'
    },
    {
      id: '2',
      title: 'Crisis to Opportunity: Rebuilding Trust After Service Disruption',
      client: 'Mountain View Bus Service',
      industry: 'Transportation',
      image: '🏔️',
      challenge: 'Major service disruption led to negative reviews and social media backlash threatening the company\'s reputation.',
      solution: 'Rapid crisis response strategy, transparent communication plan, and proactive customer outreach program.',
      results: [
        { metric: 'Review Quality', value: '+78%', description: 'Improvement in positive sentiment' },
        { metric: 'Trust Score', value: '+45%', description: 'Customer confidence increase' },
        { metric: 'New Reviews', value: '250+', description: 'Positive reviews generated' }
      ],
      testimonial: 'They helped us turn our biggest challenge into a showcase of our commitment to customers.'
    },
    {
      id: '3',
      title: 'Launching New Adventure Tourism Brand',
      client: 'Sunset Travel Adventures',
      industry: 'Adventure Tourism',
      image: '🌅',
      challenge: 'Brand new company needed to establish credibility and awareness in competitive adventure travel market.',
      solution: 'Full-service brand launch campaign including PR, influencer partnerships, and strategic content marketing.',
      results: [
        { metric: 'Brand Awareness', value: '89%', description: 'In target demographic' },
        { metric: 'Press Coverage', value: '15', description: 'Major publications' },
        { metric: 'Revenue Growth', value: '+140%', description: 'Exceeded projections by 40%' }
      ],
      testimonial: 'They helped us go from unknown startup to recognized brand in less than a year.'
    },
    {
      id: '4',
      title: 'Heritage Brand Modernization',
      client: 'Heritage Coach Lines',
      industry: 'Luxury Transportation',
      image: '🎩',
      challenge: '50-year-old company struggling to appeal to younger travelers while maintaining heritage clientele.',
      solution: 'Brand repositioning strategy, social media revitalization, and targeted publicity campaigns balancing tradition with innovation.',
      results: [
        { metric: 'Millennial Bookings', value: '+120%', description: 'Growth in under-40 segment' },
        { metric: 'Social Engagement', value: '+340%', description: 'Across all platforms' },
        { metric: 'Customer Retention', value: '94%', description: 'Heritage customer loyalty' }
      ],
      testimonial: 'They helped us honor our past while embracing our future.'
    }
  ]);

  private teamMembers = signal<TeamMember[]>([
    {
      id: '1',
      name: 'Alexandra Rivera',
      position: 'Founder & CEO',
      avatar: '👩‍💼',
      bio: 'Former travel journalist turned publicity strategist with 15 years of experience in travel media and brand communications.',
      expertise: ['Brand Strategy', 'Media Relations', 'Crisis Communications'],
      social: {
        linkedin: 'https://linkedin.com/in/alexandra-rivera',
        twitter: 'https://twitter.com/alexrivera'
      }
    },
    {
      id: '2',
      name: 'Marcus Thompson',
      position: 'Director of Reputation Management',
      avatar: '👨‍💼',
      bio: 'Reputation management expert specializing in hospitality and travel sectors with proven track record of turning around negative sentiment.',
      expertise: ['Reputation Management', 'Review Strategy', 'Customer Relations'],
      social: {
        linkedin: 'https://linkedin.com/in/marcus-thompson'
      }
    },
    {
      id: '3',
      name: 'Priya Patel',
      position: 'Head of Digital Marketing',
      avatar: '👩‍💼',
      bio: 'Digital marketing strategist with deep expertise in travel industry trends, social media, and influencer partnerships.',
      expertise: ['Social Media', 'Content Strategy', 'Influencer Marketing'],
      social: {
        linkedin: 'https://linkedin.com/in/priya-patel',
        twitter: 'https://twitter.com/priyapatel'
      }
    },
    {
      id: '4',
      name: 'James O\'Connor',
      position: 'Senior Brand Consultant',
      avatar: '👨‍💼',
      bio: 'Brand strategist who has helped launch and reposition over 50 travel brands across North America.',
      expertise: ['Brand Development', 'Market Research', 'Competitive Analysis'],
      social: {
        linkedin: 'https://linkedin.com/in/james-oconnor'
      }
    }
  ]);

  private blogPosts = signal<BlogPost[]>([
    {
      id: '1',
      slug: '10-ways-build-brand-trust-online',
      title: '10 Ways to Build Brand Trust Online for Travel Businesses',
      excerpt: 'Discover proven strategies to establish credibility and earn traveler trust in the digital age.',
      content: `Building trust is essential for travel businesses in today's digital landscape. Here are 10 proven strategies...`,
      author: {
        name: 'Alexandra Rivera',
        avatar: '👩‍💼',
        bio: 'Founder & CEO'
      },
      category: 'Brand Trust',
      tags: ['branding', 'trust', 'digital marketing'],
      image: '📱',
      publishedDate: '2024-10-01',
      readTime: 8
    },
    {
      id: '2',
      slug: 'crisis-communication-playbook-travel-industry',
      title: 'Crisis Communication Playbook for the Travel Industry',
      excerpt: 'Learn how to protect your brand reputation when things go wrong with this comprehensive guide.',
      content: `Every travel business will face challenges. Here's how to handle them professionally...`,
      author: {
        name: 'Marcus Thompson',
        avatar: '👨‍💼',
        bio: 'Director of Reputation Management'
      },
      category: 'Crisis Management',
      tags: ['crisis', 'reputation', 'communication'],
      image: '🆘',
      publishedDate: '2024-09-28',
      readTime: 12
    },
    {
      id: '3',
      slug: 'power-of-online-reviews-travel-bookings',
      title: 'The Power of Online Reviews in Driving Travel Bookings',
      excerpt: 'Data-driven insights on how reviews influence booking decisions and how to leverage them.',
      content: `Reviews are the #1 factor in travel booking decisions. Here's what you need to know...`,
      author: {
        name: 'Marcus Thompson',
        avatar: '👨‍💼',
        bio: 'Director of Reputation Management'
      },
      category: 'Review Management',
      tags: ['reviews', 'bookings', 'data'],
      image: '⭐',
      publishedDate: '2024-09-25',
      readTime: 10
    },
    {
      id: '4',
      slug: 'social-media-strategy-bus-tour-companies',
      title: 'Social Media Strategy for Bus and Tour Companies',
      excerpt: 'Platform-specific tactics to grow your following and engage potential travelers.',
      content: `Social media is where travelers discover their next adventure. Here's how to stand out...`,
      author: {
        name: 'Priya Patel',
        avatar: '👩‍💼',
        bio: 'Head of Digital Marketing'
      },
      category: 'Social Media',
      tags: ['social media', 'strategy', 'engagement'],
      image: '📱',
      publishedDate: '2024-09-20',
      readTime: 9
    },
    {
      id: '5',
      slug: 'press-release-gets-media-attention',
      title: 'How to Write a Press Release That Gets Media Attention',
      excerpt: 'Master the art of the press release with templates and examples from successful campaigns.',
      content: `A great press release can earn you valuable media coverage. Follow these proven techniques...`,
      author: {
        name: 'Alexandra Rivera',
        avatar: '👩‍💼',
        bio: 'Founder & CEO'
      },
      category: 'Public Relations',
      tags: ['PR', 'press release', 'media'],
      image: '📰',
      publishedDate: '2024-09-15',
      readTime: 7
    },
    {
      id: '6',
      slug: 'influencer-marketing-travel-brands',
      title: 'Influencer Marketing for Travel Brands: A Complete Guide',
      excerpt: 'Navigate the world of travel influencers and create partnerships that drive real results.',
      content: `Influencer partnerships can amplify your reach. Here's how to do it right...`,
      author: {
        name: 'Priya Patel',
        avatar: '👩‍💼',
        bio: 'Head of Digital Marketing'
      },
      category: 'Influencer Marketing',
      tags: ['influencers', 'partnerships', 'marketing'],
      image: '🤝',
      publishedDate: '2024-09-10',
      readTime: 11
    }
  ]);

  getServices() {
    return this.services.asReadonly();
  }

  getServiceById(id: string) {
    return this.services().find(s => s.id === id);
  }

  getTestimonials() {
    return this.testimonials.asReadonly();
  }

  getCaseStudies() {
    return this.caseStudies.asReadonly();
  }

  getCaseStudyById(id: string) {
    return this.caseStudies().find(cs => cs.id === id);
  }

  getTeamMembers() {
    return this.teamMembers.asReadonly();
  }

  getBlogPosts() {
    return this.blogPosts.asReadonly();
  }

  getBlogPostBySlug(slug: string) {
    return this.blogPosts().find(bp => bp.slug === slug);
  }

  getBlogPostsByCategory(category: string) {
    return this.blogPosts().filter(bp => bp.category === category);
  }
}



