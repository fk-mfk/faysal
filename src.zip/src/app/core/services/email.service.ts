import { Injectable } from '@angular/core';
import emailjs from '@emailjs/browser';

@Injectable({
  providedIn: 'root'
})
export class EmailService {
  private readonly serviceId = 'service_trailtrustmedia';
  private readonly publicKey = 'YOUR_EMAILJS_PUBLIC_KEY'; // You'll need to replace this
  
  // Template IDs for different forms
  private readonly templates = {
    contact: 'template_contact',
    quote: 'template_quote'
  };

  constructor() {
    // Initialize EmailJS with your public key
    emailjs.init(this.publicKey);
  }

  /**
   * Send contact form email
   */
  async sendContactForm(formData: any): Promise<boolean> {
    try {
      const templateParams = {
        to_email: 'mfk8776@gmail.com',
        from_name: formData.name,
        from_email: formData.email,
        phone: formData.phone,
        company_name: formData.companyName || 'Not provided',
        business_type: formData.businessType || 'Not provided',
        website: formData.website || 'Not provided',
        selected_services: Array.isArray(formData.selectedServices) 
          ? formData.selectedServices.join(', ') 
          : formData.selectedServices || 'Not specified',
        message: formData.message || 'No message provided',
        submission_date: new Date().toLocaleString(),
        form_type: 'Contact Form'
      };

      const response = await emailjs.send(
        this.serviceId,
        this.templates.contact,
        templateParams
      );

      console.log('Contact form email sent successfully:', response);
      return response.status === 200;
    } catch (error) {
      console.error('Error sending contact form email:', error);
      return false;
    }
  }

  /**
   * Send quote request form email
   */
  async sendQuoteRequest(formData: any): Promise<boolean> {
    try {
      const templateParams = {
        to_email: 'mfk8776@gmail.com',
        from_name: formData.name,
        from_email: formData.email,
        phone: formData.phone,
        business_name: formData.businessName,
        service_interested: formData.service,
        message: formData.message,
        submission_date: new Date().toLocaleString(),
        form_type: 'Custom Quote Request'
      };

      const response = await emailjs.send(
        this.serviceId,
        this.templates.quote,
        templateParams
      );

      console.log('Quote request email sent successfully:', response);
      return response.status === 200;
    } catch (error) {
      console.error('Error sending quote request email:', error);
      return false;
    }
  }

  /**
   * Generic method to send any form data
   */
  async sendFormData(formType: string, formData: any): Promise<boolean> {
    try {
      const templateParams = {
        to_email: 'mfk8776@gmail.com',
        form_type: formType,
        form_data: JSON.stringify(formData, null, 2),
        submission_date: new Date().toLocaleString(),
        ...formData // Spread all form data
      };

      const response = await emailjs.send(
        this.serviceId,
        this.templates.contact, // Use contact template as default
        templateParams
      );

      console.log(`${formType} email sent successfully:`, response);
      return response.status === 200;
    } catch (error) {
      console.error(`Error sending ${formType} email:`, error);
      return false;
    }
  }
}

