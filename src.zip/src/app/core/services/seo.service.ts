import { Injectable, inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Meta, Title } from '@angular/platform-browser';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';

export interface SEOData {
  title: string;
  description: string;
  keywords?: string;
  author?: string;
  ogType?: string;
  ogImage?: string;
  twitterCard?: string;
}

@Injectable({
  providedIn: 'root'
})
export class SeoService {
  private title = inject(Title);
  private meta = inject(Meta);
  private router = inject(Router);
  private platformId = inject(PLATFORM_ID);
  private isBrowser = isPlatformBrowser(this.platformId);

  constructor() {
    this.trackPageViews();
  }

  updateSEO(seoData: SEOData) {
    // Update title
    this.title.setTitle(seoData.title);

    // Update meta tags
    this.meta.updateTag({ name: 'description', content: seoData.description });
    
    if (seoData.keywords) {
      this.meta.updateTag({ name: 'keywords', content: seoData.keywords });
    }
    
    if (seoData.author) {
      this.meta.updateTag({ name: 'author', content: seoData.author });
    }

    // Update Open Graph tags
    this.meta.updateTag({ property: 'og:title', content: seoData.title });
    this.meta.updateTag({ property: 'og:description', content: seoData.description });
    this.meta.updateTag({ property: 'og:type', content: seoData.ogType || 'website' });
    
    if (seoData.ogImage) {
      this.meta.updateTag({ property: 'og:image', content: seoData.ogImage });
    }

    const currentUrl = `https://trailtrustmedia.com${this.router.url}`;
    this.meta.updateTag({ property: 'og:url', content: currentUrl });

    // Update Twitter Card tags
    this.meta.updateTag({ name: 'twitter:card', content: seoData.twitterCard || 'summary_large_image' });
    this.meta.updateTag({ name: 'twitter:title', content: seoData.title });
    this.meta.updateTag({ name: 'twitter:description', content: seoData.description });
    
    if (seoData.ogImage) {
      this.meta.updateTag({ name: 'twitter:image', content: seoData.ogImage });
    }

    // Update canonical URL
    this.updateCanonicalUrl(currentUrl);
  }

  updateCanonicalUrl(url: string) {
    if (!this.isBrowser) return;
    
    let link: HTMLLinkElement | null = document.querySelector('link[rel="canonical"]');
    
    if (!link) {
      link = document.createElement('link');
      link.setAttribute('rel', 'canonical');
      document.head.appendChild(link);
    }
    
    link.setAttribute('href', url);
  }

  addStructuredData(data: object) {
    if (!this.isBrowser) return;
    
    let script: HTMLScriptElement | null = document.querySelector('script[type="application/ld+json"]');
    
    if (!script) {
      script = document.createElement('script');
      script.type = 'application/ld+json';
      document.head.appendChild(script);
    }
    
    script.textContent = JSON.stringify(data);
  }

  private trackPageViews() {
    if (!this.isBrowser) return;
    
    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: any) => {
      // Google Analytics tracking would go here
      if (typeof window !== 'undefined' && (window as any).gtag) {
        (window as any).gtag('config', 'GA_MEASUREMENT_ID', {
          page_path: event.urlAfterRedirects
        });
      }
    });
  }

  getOrganizationSchema() {
    return {
      "@context": "https://schema.org",
      "@type": "Organization",
      "name": "TrailTrustMedia",
      "description": "Publicity and Review Agency for Travel and Bus Businesses",
      "url": "https://trailtrustmedia.com",
      "logo": "https://trailtrustmedia.com/assets/logo.png",
      "contactPoint": {
        "@type": "ContactPoint",
        "telephone": "+1-555-TRAIL-01",
        "contactType": "Customer Service",
        "email": "hello@trailtrustmedia.com",
        "areaServed": "US",
        "availableLanguage": ["English"]
      },
      "sameAs": [
        "https://www.linkedin.com/company/trailtrustmedia",
        "https://twitter.com/trailtrustmedia",
        "https://www.instagram.com/trailtrustmedia"
      ],
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "123 Marketing Boulevard",
        "addressLocality": "San Francisco",
        "addressRegion": "CA",
        "postalCode": "94102",
        "addressCountry": "US"
      }
    };
  }
}

