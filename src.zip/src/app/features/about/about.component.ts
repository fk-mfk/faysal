import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { DataService } from '../../core/services/data.service';
import { SeoService } from '../../core/services/seo.service';

@Component({
  selector: 'app-about',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.scss']
})
export class AboutComponent implements OnInit {
  private dataService = inject(DataService);
  private seoService = inject(SeoService);

  values = [
    {
      icon: '🎯',
      title: 'Authenticity',
      description: 'We believe in building genuine connections between brands and travelers through honest storytelling.'
    },
    {
      icon: '💡',
      title: 'Innovation',
      description: 'Staying ahead of digital trends to provide cutting-edge marketing solutions for travel businesses.'
    },
    {
      icon: '📊',
      title: 'Results-Driven',
      description: 'Every strategy is designed to deliver measurable outcomes that impact your bottom line.'
    },
    {
      icon: '🤝',
      title: 'Partnership',
      description: 'We see ourselves as an extension of your team, invested in your long-term success.'
    }
  ];

  milestones = [
    { year: '2019', event: 'Founded TrailTrustMedia with a vision to transform travel marketing' },
    { year: '2020', event: 'Helped 50+ travel brands navigate pandemic challenges' },
    { year: '2022', event: 'Expanded services to include comprehensive review management' },
    { year: '2024', event: 'Reached 200+ clients milestone and launched AI-powered reputation tools' }
  ];

  ngOnInit() {
    this.seoService.updateSEO({
      title: 'About TrailTrustMedia - Our Story & Mission',
      description: 'Learn about TrailTrustMedia\'s mission to help travel brands build authentic online presence through strategic publicity campaigns and reputation management.',
      keywords: 'about trailtrustmedia, travel marketing agency, publicity agency story, bus operator marketing',
      ogType: 'website'
    });
  }
}



