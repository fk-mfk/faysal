import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { DataService } from '../../../core/services/data.service';
import { SeoService } from '../../../core/services/seo.service';
import { BlogPost } from '../../../core/models/blog.model';

@Component({
  selector: 'app-blog-detail',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './blog-detail.component.html',
  styleUrls: ['./blog-detail.component.scss']
})
export class BlogDetailComponent implements OnInit {
  private dataService = inject(DataService);
  private seoService = inject(SeoService);
  private route = inject(ActivatedRoute);

  post?: BlogPost;
  relatedPosts: BlogPost[] = [];

  ngOnInit() {
    const slug = this.route.snapshot.paramMap.get('slug');
    if (slug) {
      this.post = this.dataService.getBlogPostBySlug(slug);
      
      if (this.post) {
        this.seoService.updateSEO({
          title: `${this.post.title} - TrailTrustMedia Blog`,
          description: this.post.excerpt,
          keywords: this.post.tags.join(', '),
          author: this.post.author.name,
          ogType: 'article'
        });

        // Get related posts (same category, excluding current post)
        this.relatedPosts = this.dataService
          .getBlogPostsByCategory(this.post.category)
          .filter(p => p.id !== this.post?.id)
          .slice(0, 3);
      }
    }
  }
}



