import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { DataService } from '../../../core/services/data.service';
import { SeoService } from '../../../core/services/seo.service';

@Component({
  selector: 'app-blog-list',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './blog-list.component.html',
  styleUrls: ['./blog-list.component.scss']
})
export class BlogListComponent implements OnInit {
  private dataService = inject(DataService);
  private seoService = inject(SeoService);

  blogPosts = this.dataService.getBlogPosts();
  selectedCategory = signal('all');

  categories = [
    'All',
    'Brand Trust',
    'Crisis Management',
    'Review Management',
    'Social Media',
    'Public Relations',
    'Influencer Marketing'
  ];

  ngOnInit() {
    this.seoService.updateSEO({
      title: 'Travel Marketing Blog - Tips, Strategies & Industry Insights',
      description: 'Expert insights on publicity, reputation management, and digital marketing for travel businesses. Learn strategies to grow your travel brand.',
      keywords: 'travel marketing blog, publicity tips, reputation management, digital marketing strategies',
      ogType: 'website'
    });
  }

  filterByCategory(category: string) {
    this.selectedCategory.set(category);
  }

  get filteredPosts() {
    if (this.selectedCategory() === 'all' || this.selectedCategory() === 'All') {
      return this.blogPosts();
    }
    return this.blogPosts().filter(post => post.category === this.selectedCategory());
  }
}



