import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { SeoService } from '../../core/services/seo.service';
import { EmailService } from '../../core/services/email.service';

@Component({
  selector: 'app-contact',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.scss']
})
export class ContactComponent implements OnInit {
  private fb = inject(FormBuilder);
  private seoService = inject(SeoService);
  private emailService = inject(EmailService);

  currentStep = signal(1);
  totalSteps = 3;
  isSubmitted = signal(false);
  isSubmitting = signal(false);
  submitError = signal<string | null>(null);

  contactForm: FormGroup;

  services = [
    { id: 'publicity', label: 'Publicity Campaigns', icon: '📢' },
    { id: 'reviews', label: 'Review Management', icon: '⭐' },
    { id: 'digital', label: 'Digital Marketing', icon: '📱' },
    { id: 'consulting', label: 'Travel Business Consulting', icon: '💼' } //need to make it business consulting everywhere in code
  ];

  constructor() {
    this.contactForm = this.fb.group({
      // Step 1: Service Selection
      selectedServices: [[], Validators.required],
      
      // Step 2: Business Info
      companyName: ['', Validators.required],
      businessType: ['', Validators.required],
      website: [''],
      
      // Step 3: Contact Details
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', Validators.required],
      message: ['']
    });
  }

  ngOnInit() {
    this.seoService.updateSEO({
      title: 'Contact Us - Get Started with TrailTrustMedia',
      description: 'Schedule your free consultation with TrailTrustMedia. Let\'s discuss how we can help your travel business grow with strategic publicity and marketing.',
      keywords: 'contact trailtrustmedia, free consultation, travel marketing contact, publicity agency contact',
      ogType: 'website'
    });
  }

  toggleService(serviceId: string) {
    const currentServices = this.contactForm.get('selectedServices')?.value || [];
    const index = currentServices.indexOf(serviceId);
    
    if (index > -1) {
      currentServices.splice(index, 1);
    } else {
      currentServices.push(serviceId);
    }
    
    this.contactForm.patchValue({ selectedServices: currentServices });
  }

  isServiceSelected(serviceId: string): boolean {
    const selectedServices = this.contactForm.get('selectedServices')?.value || [];
    return selectedServices.includes(serviceId);
  }

  nextStep() {
    if (this.currentStep() < this.totalSteps) {
      this.currentStep.update(step => step + 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }

  previousStep() {
    if (this.currentStep() > 1) {
      this.currentStep.update(step => step - 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }

  canProceed(): boolean {
    switch (this.currentStep()) {
      case 1:
        return this.contactForm.get('selectedServices')?.value?.length > 0;
      case 2:
        return !!(this.contactForm.get('companyName')?.valid && 
               this.contactForm.get('businessType')?.valid);
      case 3:
        return this.contactForm.valid;
      default:
        return false;
    }
  }

  async onSubmit() {
    if (this.contactForm.valid && !this.isSubmitting()) {
      this.isSubmitting.set(true);
      this.submitError.set(null);

      try {
        const success = await this.emailService.sendContactForm(this.contactForm.value);
        
        if (success) {
          console.log('Form submitted successfully:', this.contactForm.value);
          this.isSubmitted.set(true);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        } else {
          this.submitError.set('Failed to send email. Please try again or contact us directly at mfk8776@gmail.com');
        }
      } catch (error) {
        console.error('Error submitting form:', error);
        this.submitError.set('An error occurred. Please try again or contact us directly at mfk8776@gmail.com');
      } finally {
        this.isSubmitting.set(false);
      }
    }
  }
}

