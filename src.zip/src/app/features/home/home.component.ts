import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { DataService } from '../../core/services/data.service';
import { SeoService } from '../../core/services/seo.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  private dataService = inject(DataService);
  private seoService = inject(SeoService);

  services = this.dataService.getServices();
  testimonials = this.dataService.getTestimonials();
  displayedTestimonials = signal(this.testimonials().slice(0, 3));

  stats = [
    { value: '200+', label: 'Bus Operators Helped', icon: '🚌' },
    { value: '4.9★', label: 'Avg. RedBus Rating Improved', icon: '⭐' },
    { value: '100K+', label: 'Reviews Managed', icon: '💬' },
    { value: '85%', label: 'Avg. Booking Increase', icon: '🚀' }
  ];

  redbusAchievement = {
    rating: '4.9',
    platform: 'RedBus',
    icon: '🚌',
    beforeRating: '3.2',
    afterRating: '4.9',
    timeframe: '6 months',
    reviewsManaged: '2,500+',
    bookingIncrease: '85%'
  };

  ngOnInit() {
    this.seoService.updateSEO({
      title: 'TrailTrustMedia - #1 Bus Operator Rating & Review Management Agency',
      description: 'Boost your RedBus, Paytm & AbhiBus ratings to 4.9★. Specialized review management for bus operators that increases bookings by 85%. Proven results for 200+ operators.',
      keywords: 'redbus rating increase, bus operator reviews, abhibus ratings, paytm bus reviews, review management, bus agency marketing, reputation management, increase bus bookings',
      ogType: 'website'
    });

    this.seoService.addStructuredData(this.seoService.getOrganizationSchema());
  }
}



