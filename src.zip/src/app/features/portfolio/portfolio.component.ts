import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { DataService } from '../../core/services/data.service';
import { SeoService } from '../../core/services/seo.service';

@Component({
  selector: 'app-portfolio',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './portfolio.component.html',
  styleUrls: ['./portfolio.component.scss']
})
export class PortfolioComponent implements OnInit {
  private dataService = inject(DataService);
  private seoService = inject(SeoService);

  caseStudies = this.dataService.getCaseStudies();

  industries = [
    { 
      name: 'Travel & Tourism', 
      icon: 'beach',
      count: 85,
      color: '#3b82f6',
      gradient: 'linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)',
      stats: {
        avgRating: '4.7★',
        growth: '+125%',
        satisfaction: '98%'
      },
      description: 'Hotels, resorts, and vacation experiences',
      achievements: ['Top performer', 'Highest growth']
    },
    { 
      name: 'Transportation', 
      icon: 'bus',
      count: 62,
      color: '#10b981',
      gradient: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
      stats: {
        avgRating: '4.6★',
        growth: '+98%',
        satisfaction: '94%'
      },
      description: 'Bus services, tour operators, and fleet management',
      achievements: ['Most reviewed', 'Crisis recovery expert']
    },
    { 
      name: 'Cargo & Logistics', 
      icon: 'package',
      count: 28,
      color: '#f59e0b',
      gradient: 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)',
      stats: {
        avgRating: '4.5★',
        growth: '+87%',
        satisfaction: '92%'
      },
      description: 'Freight, shipping, and delivery services',
      achievements: ['Fast turnaround', 'B2B specialist']
    },
    { 
      name: 'Adventure Tourism', 
      icon: 'mountain',
      count: 34,
      color: '#8b5cf6',
      gradient: 'linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%)',
      stats: {
        avgRating: '4.8★',
        growth: '+142%',
        satisfaction: '98%'
      },
      description: 'Trekking, rafting, and extreme sports',
      achievements: ['Premium brand', 'Social media star']
    },
    { 
      name: 'Luxury Travel', 
      icon: 'luxury',
      count: 19,
      color: '#ec4899',
      gradient: 'linear-gradient(135deg, #ec4899 0%, #db2777 100%)',
      stats: {
        avgRating: '4.9★',
        growth: '+156%',
        satisfaction: '99%'
      },
      description: 'High-end tours, private jets, and concierge',
      achievements: ['Elite service', 'VIP clientele']
    }
  ];
  
  getIndustryIcon(iconName: string): string {
    const icons: { [key: string]: string } = {
      beach: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M12 18.5L11.3 18.3C9.3 17.7 7.5 16.5 6 15C4.5 13.5 3.3 11.7 2.7 9.7L2.5 9L3.2 8.7C5.2 7.9 7.4 7.5 9.5 7.5C11.6 7.5 13.8 7.9 15.8 8.7L16.5 9L16.3 9.7C15.7 11.7 14.5 13.5 13 15C11.5 16.5 9.7 17.7 7.7 18.3L7 18.5M12 2V6M16 4L14 7M8 4L10 7M17 8L14 10M7 8L10 10M21 12H17M7 12H3"/>
        <circle cx="12" cy="20" r="2"/>
      </svg>`,
      bus: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M17 20H7V21C7 21.5523 6.55228 22 6 22H5C4.44772 22 4 21.5523 4 21V20H3V12H2V8H3V5C3 3.89543 3.89543 3 5 3H19C20.1046 3 21 3.89543 21 5V8H22V12H21V20H20V21C20 21.5523 19.5523 22 19 22H18C17.4477 22 17 21.5523 17 21V20Z"/>
        <path d="M5 5V11H19V5H5Z"/>
        <circle cx="7" cy="16" r="1.5"/>
        <circle cx="17" cy="16" r="1.5"/>
      </svg>`,
      package: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
        <polyline points="3.27 6.96 12 12.01 20.73 6.96"/>
        <line x1="12" y1="22.08" x2="12" y2="12"/>
      </svg>`,
      mountain: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="m8 3 4 8 5-5 5 15H2L8 3z"/>
        <path d="M4.14 15.08c2.62-1.57 5.24-1.43 7.86.42 2.74 1.94 5.49 2 8.23.19"/>
      </svg>`,
      luxury: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="m2 7 4.41-4.41A2 2 0 0 1 7.83 2h8.34a2 2 0 0 1 1.42.59L22 7"/>
        <path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/>
        <path d="M15 22v-4a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4"/>
        <path d="M2 7h20"/>
        <path d="M22 7v3a2 2 0 0 1-2 2v0a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 16 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 12 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 8 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 4 12v0a2 2 0 0 1-2-2V7"/>
      </svg>`
    };
    return icons[iconName] || '';
  }
  
  getCaseStudyIconClass(emoji: string): string {
    // Map emoji to corresponding industry class
    const iconMap: { [key: string]: string } = {
      '🚌': 'bus-icon',
      '🏔️': 'mountain-icon',
      '🌅': 'sunset-icon',
      '🎩': 'luxury-icon'
    };
    return iconMap[emoji] || 'default-icon';
  }

  ngOnInit() {
    this.seoService.updateSEO({
      title: 'Portfolio & Case Studies - TrailTrustMedia Success Stories',
      description: 'Explore real success stories from travel brands we\'ve helped grow. See the results of our publicity campaigns, review management, and digital marketing.',
      keywords: 'case studies, portfolio, success stories, travel marketing results, client testimonials',
      ogType: 'website'
    });
  }
}



