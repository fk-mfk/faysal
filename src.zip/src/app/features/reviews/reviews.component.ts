import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { DataService } from '../../core/services/data.service';
import { SeoService } from '../../core/services/seo.service';

@Component({
  selector: 'app-reviews',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './reviews.component.html',
  styleUrls: ['./reviews.component.scss']
})
export class ReviewsComponent implements OnInit {
  private dataService = inject(DataService);
  private seoService = inject(SeoService);

  selectedFilter = signal('all');

  anonymousTestimonials = [
    {
      id: '1',
      text: 'Outstanding service! Our RedBus rating went from 3.1 to 4.8 in just 5 months. Bookings increased by 92% and we\'re now ranking in the top operators.',
      type: 'Verified Bus Operator',
      location: 'Delhi NCR Region'
    },
    {
      id: '2',
      text: 'The publicity campaign exceeded all expectations. We were featured in 5 major travel publications and saw a 180% increase in brand searches. Their strategic approach is unmatched!',
      type: 'Verified Travel Agency',
      location: 'Maharashtra'
    },
    {
      id: '3',
      text: 'Professional team that understands the bus industry. They helped us manage reviews across all platforms and our reputation has never been better.',
      type: 'Verified Bus Service',
      location: 'Karnataka'
    },
    {
      id: '4',
      text: 'The review management services are game-changers. Our response rate is now 100%, customers love our engagement, and our ratings improved across all channels.',
      type: 'Verified Bus Operator',
      location: 'Gujarat'
    },
    {
      id: '5',
      text: 'Their WhatsApp and social media campaigns delivered incredible results! We gained 2,000+ followers and generated 500+ qualified leads. The ROI is outstanding!',
      type: 'Verified Travel Company',
      location: 'Rajasthan'
    },
    {
      id: '6',
      text: 'Managing reviews across RedBus, Paytm, and AbhiBus was overwhelming until they stepped in. They monitor 24/7 and respond professionally. Bookings are up 85%!',
      type: 'Verified Bus Service',
      location: 'Tamil Nadu'
    },
    {
      id: '7',
      text: 'Best investment we made for our business. The ROI is incredible - for every rupee spent, we\'re seeing 8x return through increased bookings.',
      type: 'Verified Travel Agency',
      location: 'Uttar Pradesh'
    },
    {
      id: '8',
      text: 'The SMS and email marketing campaigns are incredibly effective. Our repeat booking rate jumped from 15% to 42%. Simply phenomenal results!',
      type: 'Verified Bus Operator',
      location: 'West Bengal'
    }
  ];

  ngOnInit() {
    this.seoService.updateSEO({
      title: 'Client Reviews & Testimonials - TrailTrustMedia',
      description: 'Read what our clients say about TrailTrustMedia. Real reviews from travel businesses we\'ve helped grow their online presence and bookings.',
      keywords: 'client reviews, testimonials, customer feedback, travel marketing reviews',
      ogType: 'website'
    });
  }

  filterTestimonials(filter: string) {
    this.selectedFilter.set(filter);
  }
}



