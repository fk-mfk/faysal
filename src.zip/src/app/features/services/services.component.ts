import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { DataService } from '../../core/services/data.service';
import { SeoService } from '../../core/services/seo.service';
import { EmailService } from '../../core/services/email.service';

interface QuoteForm {
  name: string;
  email: string;
  phone: string;
  businessName: string;
  service: string;
  message: string;
}

@Component({
  selector: 'app-services',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.scss']
})
export class ServicesComponent implements OnInit {
  private dataService = inject(DataService);
  private seoService = inject(SeoService);
  private emailService = inject(EmailService);

  services = this.dataService.getServices();
  
  quoteForm: QuoteForm = {
    name: '',
    email: '',
    phone: '',
    businessName: '',
    service: '',
    message: ''
  };
  
  formSubmitted = false;
  isSubmitting = false;
  submitError: string | null = null;

  ngOnInit() {
    this.seoService.updateSEO({
      title: 'Our Services - Publicity, Review Management & Digital Marketing',
      description: 'Comprehensive digital marketing services for travel businesses: publicity campaigns, review management, social media marketing, and brand consulting.',
      keywords: 'publicity services, review management, digital marketing, brand consulting, travel marketing services',
      ogType: 'website'
    });
  }
  
  scrollToQuote(serviceTitle: string) {
    this.quoteForm.service = serviceTitle;
    const element = document.getElementById('quote-form');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
      // Focus on form after scroll
      setTimeout(() => {
        const firstInput = element.querySelector('input');
        firstInput?.focus();
      }, 800);
    }
  }
  
  async submitQuoteForm() {
    if (this.isSubmitting) return;
    
    this.isSubmitting = true;
    this.submitError = null;
    
    try {
      const success = await this.emailService.sendQuoteRequest(this.quoteForm);
      
      if (success) {
        console.log('Quote form submitted successfully:', this.quoteForm);
        this.formSubmitted = true;
        
        // Reset form after 5 seconds
        setTimeout(() => {
          this.formSubmitted = false;
          this.quoteForm = {
            name: '',
            email: '',
            phone: '',
            businessName: '',
            service: '',
            message: ''
          };
        }, 5000);
      } else {
        this.submitError = 'Failed to send request. Please try again or contact us directly at mfk8776@gmail.com';
      }
    } catch (error) {
      console.error('Error submitting quote form:', error);
      this.submitError = 'An error occurred. Please try again or contact us directly at mfk8776@gmail.com';
    } finally {
      this.isSubmitting = false;
    }
  }
}



